package com.redhat.encryption;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EncryptionServiceApplicationTests {

    @Test
    void contextLoads() {
    }
}